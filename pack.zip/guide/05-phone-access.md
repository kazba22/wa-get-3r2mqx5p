# 05. Reaching your agent from your phone

## The problem

Aside has no iPhone or Android app. It runs on a Mac or Windows computer. If you are in a meeting room, on a train or at a client site, you cannot open Aside to ask something.

## The solution: message a bot

Aside has a feature called Channels. You create a private bot in Telegram, Slack or Discord and give its key to Aside. From then on you chat with the bot on your phone, and Aside, running on your computer, does the work and replies in the same chat.

```
Your phone (Telegram)  ->  your private bot  ->  Aside on your computer  ->  Gmail, Calendar, Sheets, CRM
                       <-  reply in the chat <-
```

Requirements:

- Pro plan (20 USD per month as of 24 November 2026). Channels is not on Free.
- The computer must be on, awake and signed in, with Aside open.
- Telegram is the easiest. Use it unless your company already lives in Slack.

## Setup: Telegram (about 15 minutes)

Part A. Create the bot

1. In Telegram, search for @BotFather and open the official one (blue tick).
2. Send /newbot.
3. Choose a display name, for example "My Work Agent".
4. Choose a username that ends in bot. Make it hard to guess. Do not use your name or company. Random letters and numbers are best. If someone can guess the username they can find your bot (they still cannot use it, see pairing below).
5. BotFather replies with a token, a long code like 123456789:AA.... Copy it. Treat it like a password: do not post it, do not email it.
6. Optional, for group chats: in BotFather open /mybots, choose your bot, Bot Settings, enable Allow Groups, and under Group Privacy choose Turn off.

Part B. Connect it to Aside

1. In Aside open Settings > Channels.
2. Choose Telegram. Choose Manual and paste the token. (Or choose Create with Aside and let it do the steps for you.)
3. Wait a few seconds. The connection should show as connected.

Part C. Pair yourself

1. In Telegram open your new bot and press Start. Send "hello".
2. New connections accept only you ("Only me" access). If Aside does not recognise you automatically, open the connection in Settings > Channels, go to the Pairing tab, and approve your own request. Requests expire after one hour.
3. Leave access on "Only me". Do not choose "Everyone". Anyone allowed could ask the bot to read your email.

Part D. Test

Send from your phone:

> What is on my calendar for the rest of today?

You should get the answer in the chat.

## Commands you can send the bot

| Message | What it does |
|---|---|
| /new | Start a fresh conversation |
| /stop (or the word stop) | Stop the task that is running |
| /sessions | List your recent conversations and switch between them |
| /model | Choose the AI model |
| /effort | Choose how hard it thinks (low is cheaper and faster) |
| /usage | See how many credits you used |

Other things to know:

- Each chat thread is one task. Reply in the same thread to continue it.
- If you send a message while it is working, it is queued as a follow up.
- You can send attachments up to 20 MB (a photo of a business card, a PDF).
- Telegram voice notes are reported to be transcribed into tasks. Test this before relying on it.

## Good things to ask from the phone

- "What needs my reply today? Top 5 only."
- "Draft a reply to the email from Anna about the offer. Say yes to Thursday. Save as draft, do not send."
- "What is my next meeting and who is it with? Give me a 5 line prep."
- "Add to my CRM: met Jonas at the conference, interested in the Premium plan, follow up next Tuesday."
- "Move my 15:00 meeting with Pia to Thursday morning. Propose two times to me first."
- "Add a row to the Expenses sheet: 42.50, taxi, client visit, today."

See templates/phone-cheat-sheet.md for a printable list.

## Keeping the computer available

The bot only answers when the computer is on and Aside is running.

Best: a spare computer that stays on.
1. Use a laptop or mini PC that you leave plugged in at home or at the office.
2. Turn off sleep when plugged in (Windows: Settings > System > Power. Mac: Settings > Battery or Energy).
3. Sign in to Aside, Gmail, Calendar and your CRM on that computer.
4. Set Aside to start when the computer starts, if the setting exists on your system.
5. Do not use this computer for anything risky. It holds your logged in sessions.

Acceptable: your own work laptop. It works while it is open and awake. When you close the lid, the bot goes silent. Warn yourself: no answer on the phone means the laptop is asleep.

## If you cannot or do not want to pay for Pro

You can still get a lot from a phone using the task inbox pattern.

1. Create a Google Sheet called Aside Inbox with columns: Date, Request, Status, Result.
2. Open the Google Sheets app on your phone and add a row: "Draft a reply to Anna accepting Thursday" with Status = new.
3. A routine (Free allows 3) runs every 30 minutes during work hours. It reads rows with Status = new, does them at Level 1 (drafts only), writes the result in the Result column and sets Status = done.
4. You read the Result in the Sheets app, or check your drafts in the Gmail app.

Delay is up to 30 minutes and there is no chat, but it costs nothing extra. The routine prompt is in templates/prompt-library.md under "Task inbox".

A second free option is the morning and evening briefing (guide 10). The agent writes the briefing as a note you open on your phone.

## Remote desktop apps

Some people connect to their office computer from their phone with a remote desktop app. This can work as a backup for ordinary use, but it gives full control of your computer from your phone. If you do this, use a strong password, two step sign in and a company approved tool. Ask IT first.

## Security for phone access

- The bot token is a key. Never share it. If you think it leaked, open BotFather, choose your bot, and regenerate the token, then paste the new one into Aside.
- Keep access on "Only me". Do not add the bot to groups where strangers can talk to it.
- Lock your phone. Anyone holding your unlocked phone can use your bot.
- Never send passwords or card numbers in the chat.
- Aside gives Slack and Discord equivalents. Slack needs two tokens and permission to install apps in your workspace. Ask your Slack admin. Discord needs a bot token, application ID and public key from the Discord developer portal. Telegram is far simpler.

## Check yourself

- [ ] Pro plan active (or task inbox sheet set up instead)
- [ ] Bot shows connected in Settings > Channels
- [ ] You are the only paired person
- [ ] Phone test message answered
- [ ] Computer stays awake during the workday
