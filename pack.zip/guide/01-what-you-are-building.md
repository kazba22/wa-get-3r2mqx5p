# 01. What you are building

## The idea in one paragraph

Aside is a web browser with an AI agent inside it. Because it is your browser, it is already logged in to the things you use: Gmail, Google Calendar, Google Sheets, your CRM, Notion. When you give it a task, it opens those pages and works in them the way you would, but faster. You are not wiring systems together. You are teaching an assistant how you like things done.

## Three ideas to understand

**1. Tasks.** You type a request, the agent does it and reports back. Example: "Summarise my unread email from today and tell me what needs a reply."

**2. Skills and rules.** Written instructions the agent follows every time. Your rules file says who you are and what it may never do. A skill says how to do one kind of job well, for example how to triage an inbox. You write them once and stop repeating yourself.

**3. Routines.** A task on a schedule. "Every weekday at 8:00, prepare my morning briefing." The agent starts a new task by itself at that time.

## What a good result looks like

You open your laptop at 8:30. A briefing is waiting: 4 emails need you, 6 are handled or can be ignored, 2 drafts are ready for you to check, your 11:00 meeting has a one page prep note, and one client has not replied in 5 days. You spend 10 minutes instead of 60.

## What it is not

- It is not a person. It does not know your company unless you tell it.
- It does not run on its own servers. It runs on your computer.
- It is not perfect at reading every web page. Sometimes a button moves and it needs a second try.
- It is not a safe place to put secrets in plain text. Passwords stay in the Aside password manager. The agent can use them to sign in, but cannot read them.

## Who this pack is for

Office staff: administrators, sales and account people, project coordinators, assistants, freelancers. Anyone whose day is email, a CRM or notes, spreadsheets and meetings.

## Before you start: get permission

If you use a work computer or work accounts, ask your manager or IT team first. Say: "I want to use an AI assistant that can read and draft in my work email and calendar. I will check everything before it is sent." Some companies forbid sending customer data to AI tools. Following your company policy comes before anything in this pack.

## Costs

As of 24 November 2026 (check aside.com/pricing):

| Plan | Price | Relevant for you |
|---|---|---|
| Free | 0 | 500 credits per month, 3 routines. Enough to learn and run a few routines |
| Pro | 20 USD per month | Unlimited routines and Channels, which is how you message the agent from your phone |
| Max | 200 USD per month | Heavy use. Not needed for an office assistant |

Start on Free. Move to Pro when you want phone access or more than 3 routines.
