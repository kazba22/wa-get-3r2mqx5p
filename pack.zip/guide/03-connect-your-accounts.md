# 03. Connect your accounts

There is nothing to "connect" in the technical sense. The agent uses the accounts you are already signed in to inside Aside. Your job is to sign in cleanly and to tell the agent which account is which.

Time: 30 minutes.

## Step 1. Sign in to each tool inside Aside

Open each of these and sign in. Tick "stay signed in".

| Tool | Address | Used for |
|---|---|---|
| Gmail | mail.google.com | Email |
| Google Calendar | calendar.google.com | Calendar and Meet links |
| Google Sheets | sheets.google.com | Spreadsheets |
| Your CRM | HubSpot, Pipedrive, Attio, Notion or another | Contacts and deals |
| Your notes app | Notion, Google Docs or another | Notes and meeting summaries |

If you use Outlook and Microsoft 365 instead of Google, the agent can still work in the web version (outlook.office.com) like a person would. The built in shortcuts described in the skills are for Google, so Outlook work is slower and more fragile. Tell your instructor.

## Step 2. Use the Aside Password Manager

Saved passwords stay hidden from the agent. It can sign you in when needed, but the password text itself is never shown to it. Import your passwords from your old browser or password manager, or save them as you log in. Do not type passwords into chat messages or notes.

## Step 3. Two work accounts?

Many people have a personal Google account and a work one. Tell the agent which is which. Ask:

> List the Google accounts I am signed in to in this browser. I will tell you which one is work and which is personal.

Then reply, for example: "Account 1 is work (name@company.com). Account 2 is personal. Never touch personal unless I say so." Put this in your rules file too (templates/about-me-and-rules.md).

## Step 4. Set up your CRM and notes space

If you already have a CRM, you are done. If you do not:

- Small team or solo: a Notion database or a Google Sheet with columns Name, Company, Email, Stage, Last contact, Next step, Notes is enough to start.
- Sales team with deals: HubSpot free tier, Pipedrive or Attio.

Keep it simple. A tidy sheet beats a complicated CRM nobody updates.

## Step 5. Create two folders and one label

These make the agent safe and easy to supervise.

- Gmail label named Aside Drafts. The agent files things it prepared for you here.
- Gmail label named Aside Handled. Things it sorted.
- A Google Drive folder named Aside Work. Reports and summaries it makes go here.

## Step 6. Test read access in each tool

Run these one at a time, in Read only mode:

> Open my Google Calendar and list my meetings for tomorrow with time, title and attendees. Change nothing.

> Open this spreadsheet [paste link] and tell me what columns it has and how many rows of data.

> Open my CRM and tell me how many contacts or deals I have. Change nothing.

## Check yourself

- [ ] Signed in to Gmail, Calendar, Sheets, CRM and notes inside Aside
- [ ] Passwords stored in the Aside Password Manager
- [ ] The agent knows which account is work and which is personal
- [ ] Labels Aside Drafts and Aside Handled exist
- [ ] Each read test returned correct information
