# 10. Routines: the agent works on a schedule

A routine is a saved task plus a time. Aside starts it automatically.

## How routines work

- Two types: cron (starts a fresh task on a schedule) and heartbeat (continues an existing chat). Use cron for almost everything here.
- Create one in Settings > Routines, or ask Aside in a chat: "Create a routine that runs every weekday at 8:00 and does X".
- You can pause, edit, delete or run a routine now.
- Routines only run while the computer is awake and Aside is running. If it was off, it does not catch up on missed ones. Overlapping runs are skipped.
- Free plan: up to 3 active routines. Pro: unlimited.
- You can set explicit permissions for a scheduled run. Make routines Read only or Guard, never Full access.

## Your first three routines (fits the Free plan)

### 1. Morning briefing, weekdays at 8:00

Combines email, calendar and CRM into one note. Full text in templates/prompt-library.md. It:

- Lists what needs you in the inbox
- Lists today's meetings and prepares a short brief for each
- Lists follow ups due today
- Saves everything as a Google Doc (or a draft email to yourself) in Aside Work

### 2. Drafts and follow ups, weekdays at 12:30 (from Level 1)

- Drafts replies for new Needs me emails
- Drafts nudges for threads waiting more than 3 days
- Leaves them in Aside Drafts

### 3. End of day wrap up, weekdays at 17:30

- What changed today (list of every action the agent took)
- Open items for tomorrow
- Meetings that need follow up notes

Later routines: weekly report on Friday, weekly CRM review, monthly spreadsheet check, task inbox from your phone (guide 05).

## How to write a good routine prompt

Every routine prompt has these parts:

1. The skills to use ("Use office-inbox-manager and office-calendar-meetings")
2. The exact job
3. What it may change (usually: nothing, or drafts only)
4. What it must never do
5. Where to put the result
6. What to do when unsure ("write it in the report and do not act")

## Check a routine for two weeks

For the first 10 working days, read every output. Note mistakes and add a rule or a sentence to the routine each time. After that, spot check twice a week.

## If a routine did not run

- Was the computer awake and Aside open at that time?
- Is the routine active (not paused)?
- Did you hit your credit limit?
- Run it now from Settings > Routines to see the error.
- A long routine can cost many credits. Shorten the prompt or run it less often.

## Getting the result on your phone

- With Pro and Channels: ask for the routine from inside your Telegram chat ("Every weekday at 8, send me my briefing here") and test it for a few days to confirm the result arrives in that chat. Delivery of routine results to chat is not guaranteed in every setup, so keep the document fallback below.
- Without Channels: save the briefing as a Google Doc and open it in the Google Docs app, or send it as a draft to your own email address.
