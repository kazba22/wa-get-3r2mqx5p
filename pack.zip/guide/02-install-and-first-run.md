# 02. Install Aside and run your first task

Time: 30 minutes.

## Step 1. Install

1. Go to aside.com/download and install the version for your computer (Mac or Windows).
2. Open Aside and create an account.
3. When it offers to import bookmarks and history from your old browser, say yes. This saves time. Saved passwords come through the Password Manager import.

## Step 2. Make it your daily browser

For the agent to be useful it must be logged in to your tools. The simplest way is to use Aside as your normal browser for work. Log in to Gmail, Calendar, Sheets and your CRM inside Aside (guide 03).

## Step 3. Learn the screen

- The main area is a normal browser.
- The side panel is where you talk to the agent. Open it and type a request.
- Settings has three places you will use: Agents (permissions), Routines, and Channels (phone).

## Step 4. Your first task (safe, read only)

Open a new task. Set the permission mode to Read only if you see the option. Type:

> Open my Gmail. Tell me how many unread emails I have and list the five most recent subjects. Do not open, reply, archive or change anything.

You should get a short list. This proves the agent can see your mailbox.

## Step 5. Second task: ask it to explain itself

> What can you do for me in Gmail, Google Calendar and Google Sheets? What can you NOT do? Be specific and short.

Read the answer. This is your first look at its limits.

## Step 6. Understand credits

Every task uses credits. Long tasks that open many pages cost more. On the Free plan you have 500 credits per month. Habits that save credits:

- Be specific ("emails from the last 24 hours", not "my email").
- Give it one job per task.
- Do not ask it to browse the whole web when you know the page.

## Step 7. Keep Aside running

The agent and your routines only work while Aside is open and your computer is awake. For now simply leave Aside open during the workday. Guide 05 covers keeping it available when you are away.

## Check yourself

- [ ] Aside installed and signed in
- [ ] Logged in to Gmail inside Aside
- [ ] Ran the read only task and got a correct count
- [ ] Know where Settings > Agents, Routines and Channels are
