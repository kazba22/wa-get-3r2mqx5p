# 06. Email: your agent looks after the inbox

Skill used: office-inbox-manager. Level to start at: 0, then 1 in week 2.

## What the agent does

1. Reads new mail and sorts it into: Needs you, Waiting on someone, FYI, Ignore.
2. Drafts replies in your voice for the Needs you pile. Drafts only.
3. Finds threads where you are waiting for an answer and suggests a nudge.
4. Builds a short daily digest.
5. At Level 2: applies labels and archives newsletters you approved.

## Week 1: Level 0, learn by reading

Run each of these once a day and check the results against your own judgement.

> Using my office-inbox-manager skill: review email that arrived in the last 24 hours. Sort into Needs me, Waiting on others, FYI, Ignore. For each Needs me item, one line saying what is asked and by when. Change nothing.

Compare with what you would have decided. Where it is wrong, tell it why. Example: "Emails from accounting@ourcompany.com are always Needs me." Ask it to add that to your rules file.

## Week 2: Level 1, drafts

First give it examples of your writing so it learns your voice.

> Look at my last 15 sent emails to customers. Describe my writing style in 8 bullet points: greeting, length, tone, sign off, how I say no, how I ask for something. Save the description in my rules file under Writing style. Show it to me first.

Then:

> For each Needs me email, write a reply draft in my style. Save it as a Gmail draft in the same thread and add the label Aside Drafts. Do not send. List the drafts you made with one line each.

Your job each morning: open the Aside Drafts label, edit, send yourself. Five minutes.

## Useful requests

| You say | Result |
|---|---|
| "Summarise this thread in 3 bullets and tell me what I owe them" | Quick catch up |
| "Find every email from [client] about the contract" | Search |
| "Which emails have I not answered for more than 3 days?" | Backlog check |
| "Draft a polite chase to everyone who has not replied to my quote from last week. Drafts only" | Follow ups |
| "Unsubscribe suggestions: list newsletters I never open" | Cleaning (you decide) |
| "Draft a reply declining this, firm but friendly" | Fast replies |

## Level 2 (only after 2 clean weeks)

> Level 2 is allowed for: applying the labels Aside Handled and Newsletter, and archiving emails from this list of senders: [list]. Everything else stays in the inbox. At the end give me the list of what you moved.

## Things that go wrong

- Drafts that sound too formal: add examples of real emails to your rules file.
- It misses an urgent email: add the sender or word to the VIP list in your rules file.
- It replies in the wrong language: write "Reply in the language of the email" in the rules.
- It drafts a reply that agrees to something you have not decided: add "never agree to prices, dates or commitments in drafts, write a placeholder like [CONFIRM DATE]".

## Never

Sending, forwarding, replying all, deleting, unsubscribing by clicking links in emails, opening attachments from unknown senders. The skill forbids these unless you approve each one.

## Check yourself

- [ ] Ran the Level 0 sort for 5 days, results mostly right
- [ ] Writing style saved in your rules
- [ ] VIP senders listed
- [ ] Drafts work and appear under Aside Drafts
