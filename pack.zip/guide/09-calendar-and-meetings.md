# 09. Calendar and meetings

Skill used: office-calendar-meetings.

## What the agent does

- Reads your calendar and tells you what is coming, and where there are clashes
- Before each meeting: a one page briefing (who, history, last emails, open points)
- Suggests times for meetings from your free time and your rules (for example no meetings before 10:00)
- Creates events and Google Meet links for you, after your approval
- After a meeting: takes your notes or transcript and writes the summary, actions and a follow up email draft

## Honest note about the calendar

Aside has built in helpers for Gmail, Sheets and Docs. For Google Calendar it uses the website the way you would: it opens calendar.google.com and clicks. That works but is slower and more fragile than email. Keep calendar requests specific.

## Week 1: read only

> Using my office-calendar-meetings skill: show tomorrow's meetings with time, title, attendees and link. Tell me about clashes, back to back meetings without a break, and meetings with no agenda. Change nothing.

## Meeting briefing (the favourite)

> Prepare a briefing for my 14:00 meeting with Mira Koch of Delta Ltd. Use my email, the CRM and my notes. Give: who she is, what we discussed last time, open items, anything she sent recently, and three questions I should ask. Maximum one page.

Do this as a routine each morning (guide 10).

## Scheduling

Safe pattern: the agent proposes, you decide.

> I need a 30 minute call with Pia Schmid next week. Look at my calendar and suggest three slots that respect my rules (no meetings before 10:00 or after 17:00, no Friday afternoons). Write a draft email offering those slots. Do not create events and do not send.

At Level 2:

> Create a 30 minute event "Call with Pia Schmid" on Tuesday 10:30 with a Meet link. Add only Pia as a guest and do not send an invitation until I say go.

Inviting guests sends a message to other people. Treat it like sending an email: it needs your approval until Level 3.

## After the meeting

Paste your rough notes, or a transcript, and say:

> Using my office-calendar-meetings skill: write the meeting summary in my template, list the actions with owners and dates, and draft a follow up email to the attendees with the actions. Draft only. Then add the notes to the CRM record for Delta Ltd.

Recording and transcription: only record a meeting if every participant knows and agrees, and your company allows it. Many video call tools have built in transcripts. The agent can summarise a transcript you give it. It is not a silent recorder and you should not use it as one.

## Phone version

- "What is my next meeting? Give me a 5 line brief."
- "I am running 10 minutes late to the 11:00 with Pia. Draft a short apology message. Do not send."
- "Find me 45 minutes for focused work tomorrow and block it as Focus."

## Never

- Send invites to external people without approval
- Cancel or move meetings that have other attendees without approval
- Accept meetings from strangers
- Share your calendar or change its sharing settings

## Check yourself

- [ ] Calendar read test correct
- [ ] Did three briefings and checked them against reality
- [ ] Meeting hours and rules written in your rules file
- [ ] After meeting summary tried once with your own notes
