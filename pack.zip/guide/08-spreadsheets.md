# 08. Spreadsheets

Skill used: office-spreadsheet-helper. Works best with Google Sheets. Excel files can be read and edited as files (xlsx), see the end.

## What the agent does

- Reads a sheet and explains what is in it
- Cleans data: fixes dates, trims spaces, removes duplicates, standardises names
- Builds summaries: totals by month, by client, by category
- Adds formulas and checks them
- Fills a tracker from emails or forms
- Produces a weekly report

## The safety method: copy, then change

Before the agent changes anything in a sheet that matters:

1. Ask it to make a copy: File > Make a copy, named "[Name] working copy [date]".
2. It works in the copy.
3. You check, then you decide what goes into the real sheet.

Google Sheets keeps Version history (File > Version history) so you can always go back.

## Week 1: read only

> Using my office-spreadsheet-helper skill: open [link]. Tell me: what each sheet is for, the column names, how many rows, any empty cells, duplicated rows, and anything that looks wrong (dates in different formats, numbers stored as text, obvious typos). Change nothing.

## Week 2: clean in a copy

> Make a copy of [link] named "Sales 2026 working copy". In the copy, fix the date column to YYYY-MM-DD, remove leading and trailing spaces, and mark duplicate rows in a new column Flag. Do not delete rows. Tell me how many cells you changed.

## Reports

> From the copy, create a new sheet named Summary with: total sales per month, per salesperson, and top 10 customers. Use formulas, not typed numbers, so it updates. Add a short note under the table explaining each formula.

"Use formulas, not typed numbers" matters. Typed numbers go stale and cannot be checked.

## Tracker filling

> Every time I forward you an invoice email I want a row in the Expenses sheet: date, supplier, amount, currency, category, invoice number, link to email. Show me the row before you add it.

## Check the agent's math

The agent can make arithmetic and formula mistakes. Always do one of:

- Ask: "Show the formula you used and explain it in one sentence."
- Check one total by hand with a calculator.
- Ask for a second pass: "Re-check the totals by a different method."

## Never

- Delete rows, columns or sheets in the original
- Overwrite formulas with values
- Change numbers in financial, payroll or legal sheets without you checking each one
- Share the sheet or change who has access

## Excel files

For .xlsx files on your computer, tell the agent the folder (give access when it asks) and ask it to work on a copy file, for example "Sales_working_copy.xlsx". It can read, edit and create workbooks, including formulas and charts. Keep the original untouched.

## Useful requests

| You say | Result |
|---|---|
| "Explain this sheet like I am new to it" | Understanding |
| "Find rows where the total does not match quantity times price" | Error check |
| "Merge these two sheets on email address and show the rows that did not match" | Join |
| "Create a pivot style summary by region and month" | Report |
| "Write a formula for days since last contact" | Formula help |
| "Turn this table into a chart and a 3 sentence summary" | Presentation |

## Check yourself

- [ ] Did the read only review on one real sheet
- [ ] Used the copy first method at least once
- [ ] Verified at least one total by hand
- [ ] Know how to open Version history
