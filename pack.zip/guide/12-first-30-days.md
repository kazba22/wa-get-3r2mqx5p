# 12. Your first 30 days

Spend 10 to 15 minutes a day. The aim is a trusted agent, not a fast one.

## Week 1: Level 0, watch

| Day | Do |
|---|---|
| 1 | Install, sign in, first read only tasks (guides 02, 03) |
| 2 | Fill in the rules file. Install the five skills |
| 3 | Run the inbox sort. Compare with your own view |
| 4 | Run a calendar briefing for tomorrow |
| 5 | Review a spreadsheet (read only). Write down every mistake the agent made this week |

Goal by Friday: you know where it is good and where it is wrong. Rules updated.

## Week 2: Level 1, drafts

| Day | Do |
|---|---|
| 6 | Teach your writing style. First reply drafts |
| 7 | Log one meeting in the CRM, with your review |
| 8 | Clean one spreadsheet copy |
| 9 | Create the morning briefing routine |
| 10 | Connect your phone (Pro) or set up the task inbox sheet |

Goal: the morning briefing is useful and you send drafts with small edits.

## Week 3: widen

| Day | Do |
|---|---|
| 11 | Add the end of day routine |
| 12 | Meeting follow up flow |
| 13 | Weekly report from your spreadsheet |
| 14 | CRM stale deals review and follow up drafts |
| 15 | Check your credits and trim expensive routines |

## Week 4: decide your level

| Day | Do |
|---|---|
| 16 to 19 | Keep reviewing. Count mistakes per day. They should fall |
| 20 | Decide: stay at Level 1, or allow Level 2 for small items (labels, archive, CRM notes) |
| 21 | Write the Level 2 rules and a daily change list |

Level 3 is optional. Do not rush it.

## Score yourself at day 30

- Minutes saved per day (honest estimate):
- Number of mistakes caught this week:
- Mistakes that reached someone else:
- Favourite task:
- Task I still do myself:
- Rule I wish I had written earlier:

If mistakes that reached someone else are not zero, stay at your current level and fix the rules first.

## Keep improving

Once a month: ask Aside "Look at my routines and recent tasks. What recurring work could be a routine or a skill?" Then read the suggestions critically.
