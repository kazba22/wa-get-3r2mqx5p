# 11. Troubleshooting

## The agent did something I did not want

1. Type "stop" (in Aside or the phone chat).
2. Undo it by hand (see Recovery in guide 04).
3. Ask: "Why did you do that? Which rule or instruction did you follow?"
4. Add a one line rule to your rules file so it does not happen again.

## It cannot find or open something

- Is the account signed in inside Aside? Open the site yourself and check.
- Did the site log you out, ask for a code, or show a "verify you are human" check? Do it yourself, then tell the agent to continue.
- Is it the right Google account? Say "use the work account".
- Page changed? Tell it: "Take a fresh look at the page and try again."
- Still stuck: give a more specific path ("open Settings, then Filters").

## It gives wrong information

- Ask for the source: "Show me the email or row where you got that."
- Do not accept totals, dates or names without a check in the first weeks.
- If it invents something, add the rule: "If you are not sure, write unknown. Never guess."

## It is slow or uses many credits

- Narrow the task: time range, label, one sheet.
- Split big jobs into smaller tasks.
- Lower /effort for simple work (phone chat command).
- Check usage with /usage in Telegram or in your account.

## My phone bot does not answer

| Check | Fix |
|---|---|
| Is the computer on and awake? | Wake it. Turn off sleep |
| Is Aside running? | Open it |
| Is the connection shown as connected in Settings > Channels? | Restart the connection from the list |
| 401 Unauthorized error | The token changed. Paste the new one from BotFather |
| Bot ignores you in a group | Group Privacy still on. Turn it off in BotFather, then remove and re-add the bot |
| Works in direct chat but not group | Mention the bot by its username |
| It says you are not allowed | Approve your own request in the connection's Pairing tab |
| Still nothing | Plan is Free. Channels needs Pro |

## A routine did not run

See guide 10: awake, active, credits, run it now.

## Sheets problems

- Large sheets: the agent may read only part of a very big sheet. Ask it to state how many rows it read and compare with what you see.
- Write failed: close extra Sheets tabs and ask again.
- Wrong values: restore from Version history.

## Safety incident checklist

If the agent sent something wrong or exposed something:

1. Stop the agent.
2. Tell the recipient or your manager quickly and honestly.
3. Change your passwords if a credential might have leaked. Regenerate your Telegram bot token in BotFather.
4. Tighten the rules and move down one trust level.

## When to ask your instructor

- Anything involving client data, finance or legal documents
- Anything that sends messages to many people
- Anything you do not understand after two tries
