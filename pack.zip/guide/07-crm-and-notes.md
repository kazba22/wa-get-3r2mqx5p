# 07. CRM and notes

Skill used: office-crm-notes.

## What the agent does

- After a call or meeting: logs a note, updates the contact or deal, records the next step and date.
- Before a meeting: pulls up the history for that person.
- Weekly: lists deals and contacts with no activity and drafts follow ups.
- Turns messy notes (yours, or a meeting transcript) into a clean summary with decisions and actions.

## Rule of this guide: one source of truth

Choose where the record lives. The agent writes in that one place. Do not make it update three systems.

Example setups:

| Your situation | Good choice |
|---|---|
| Just starting, few contacts | A Notion database or Google Sheet |
| Sales with deals and stages | HubSpot, Pipedrive or Attio |
| Mostly notes and projects | Notion or Google Docs |

## Prepare the CRM so the agent can work well

1. Short list of stages, such as New, Contacted, Meeting booked, Proposal sent, Won, Lost.
2. Fields it should fill: Last contact date, Next step, Next step date, Notes.
3. One person's name per record, with their email. The email is how the agent matches an email thread to a contact.
4. Tell the agent the stage meanings in your rules file.

## Level 0 (week 1): read and suggest

> Using my office-crm-notes skill: here are my notes from today's call with Mira Koch at Delta Ltd: [paste]. Show me exactly what you would write in the CRM: the note, the stage change, the next step and date. Do not change the CRM yet.

Check that it did not invent anything. If a date or amount is not in your notes, it must write "unknown".

## Level 1-2: write notes and fields

> Same notes. Now update the CRM record for Mira Koch. Add the note, set Next step and Next step date, and leave the stage unchanged. Then show me what you changed.

Rules the skill enforces:

- Never create a duplicate: search for the person and company first.
- Never delete a record or merge duplicates without asking.
- Never change a deal amount or stage without your say so.
- Write facts only, with the date. Anything uncertain is marked "to confirm".

## Meeting notes template

The agent writes notes in this shape:

```
Meeting: [title], [date], [attendees]
Purpose:
Key points:
Decisions:
Actions: [who] to [do what] by [when]
Open questions:
Next meeting:
```

## Useful requests

| You say | Result |
|---|---|
| "Who is Mira Koch? Show our history: emails, meetings and last note" | One page brief |
| "List deals with no activity for 14 days" | Follow up list |
| "Draft follow ups for those. Drafts only" | Drafts in Gmail |
| "Turn these voice note transcripts into CRM notes" | Cleanup |
| "Create a note page for the Delta project with sections: goal, people, status, next steps" | New page |
| "Every Friday, list what changed in my CRM this week" | Review |

## Phone version

Message your bot right after a meeting: "Log: met Jonas Pak at Nord Ltd, 30 minutes, interested in the annual plan, wants a quote by Friday. Update CRM, set follow up for Friday." Check the change list it replies with.

## Privacy

CRM records contain other people's personal data. Do not put data in notes that you would not be comfortable showing the person. Follow your company policy and local privacy law. Do not paste ID numbers, health information or bank details into notes.

## Check yourself

- [ ] One place chosen for contacts and notes
- [ ] Stages and fields defined and written in your rules
- [ ] Level 0 note suggestions checked 5 times
- [ ] No duplicates created in the first week
