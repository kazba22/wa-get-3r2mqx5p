# Work Agent Starter Pack

Set up Aside as your own work assistant. It looks after your email, your CRM and notes, your spreadsheets, and your calendar and meetings.

This pack is for people who have never built anything with AI. You do not need to code. You need a computer, about three hours for setup, and the willingness to check the agent's work for the first two weeks.

## Fastest way: let your agent set you up

Read onboarding/1-student-quickstart.md. In short: install Aside, connect your Claude subscription, paste the prompt in onboarding/bootstrap-prompt.txt, and answer the agent's questions. It builds your rules, skills, routines and 30 day plan for you. The guides below are the reference behind it and the manual route.

## What you will have at the end

| Area | What your agent does | Where you check it |
|---|---|---|
| Email | Reads your inbox every morning, sorts it, drafts replies in your voice, reminds you about threads waiting on others | A short morning summary and a folder of drafts |
| CRM and notes | Logs calls and meetings, updates contact records, writes meeting notes, lists follow-ups | Your CRM or notes app |
| Spreadsheets | Cleans data, builds weekly reports, fills trackers, explains numbers | Your Google Sheets |
| Calendar and meetings | Prepares a briefing before each meeting, proposes times, writes the summary and follow-up draft after | Your calendar and your drafts |
| Phone | You message the agent from Telegram or Slack while you are away from the desk | Your phone |

## The honest limits (read this first)

1. Aside has no phone app. It runs on a Mac or Windows computer. To reach it from your phone you message a bot in Telegram, Slack or Discord. That feature (Channels) needs the Pro plan. Guide 05 explains this and a free workaround.
2. The agent works on your computer, in your logged-in browser. If the computer is off, asleep, or Aside is closed, nothing runs and the bot does not answer.
3. The agent makes mistakes. That is why this pack uses a trust ladder: it starts by only reading, then drafting, and only later acting on its own.
4. You stay responsible for anything sent in your name. Never let it send, pay, sign or delete unchecked in the first weeks.

## How to use this pack

Follow the guides in order. Each takes 20 to 40 minutes.

| Step | File | Time |
|---|---|---|
| 1 | guide/01-what-you-are-building.md | 10 min |
| 2 | guide/02-install-and-first-run.md | 30 min |
| 3 | guide/03-connect-your-accounts.md | 30 min |
| 4 | guide/04-safety-and-trust-ladder.md | 20 min |
| 5 | templates/about-me-and-rules.md (fill in, then give to Aside) | 20 min |
| 6 | Install the skills in skills/ (instructions below) | 10 min |
| 7 | guide/05-phone-access.md | 30 min |
| 8 | guide/06 to 09: email, CRM and notes, spreadsheets, calendar | 20 min each |
| 9 | guide/10-routines.md | 30 min |
| 10 | guide/12-first-30-days.md | read once, follow daily |

Problems: guide/11-troubleshooting.md.

## Installing the skills

If you used the setup interview, your agent installs the right skills for you and you can skip this section.

A skill is a short instruction file that teaches Aside how you want a type of work done. This pack has seven:

- office-agent-onboarding (the setup interview)
- office-agent-coach (weekly and monthly reviews, new ideas)
- office-inbox-manager
- office-crm-notes
- office-spreadsheet-helper
- office-calendar-meetings
- office-daily-briefing

To install, open Aside, start a new task and paste:

> I have a folder called work-agent-starter-pack. Inside it is a folder called skills with seven skill folders. For each one, use the skill-creator skill to save the whole folder (SKILL.md and any references inside) as one of my user skills, keeping the text exactly as written. Then list the skills you installed.

Give Aside access to the folder when it asks.

## Folder map

- guide/ : the step by step guides
- templates/ : things you fill in or copy (your rules, prompts, phone cheat sheet)
- onboarding/ : the quick start, the paste prompt and the agent's setup instructions
- skills/ : seven installable skills

Information about Aside plans, limits and settings was checked on 24 November 2026 against Aside's public help pages. Aside changes often, so confirm plan details at aside.com/pricing and docs.aside.com.