# Quick start: from zero to your own work agent

You do this once, about 45 to 60 minutes. Most of it is a conversation with your new agent, which asks you questions and then builds your setup.

## Step 1. Get your tools (10 minutes)

1. Download and install Aside from aside.com/download (Mac or Windows). Create your account.
2. Get a Claude subscription (Pro or Max) at claude.ai if you do not have one. Aside can use your Claude subscription as its brain.
3. Connect it: in Aside open Settings > Models > Providers > Connect > Subscription > Claude Subscription. Sign in with your Claude account in the window that opens and approve. You do not need an API key.
4. In the task model picker, choose a Claude model. A label saying "Subscription" next to Claude confirms it is connected.

Notes:
- Aside has its own free plan with credits. A connected Claude subscription is separate from those credits.
- Aside's own help pages describe supported subscription providers. Check docs.aside.com/help/ai if the menus look different, because the app changes often.
- If you also want to message your agent from your phone, you will later need Aside's Pro plan (guide 05). You can skip that for now.

## Step 2. Get the Starter Pack (5 minutes)

Open a new Aside task and paste the short prompt you received (the same text as `bootstrap-prompt.txt`). It tells Aside to read and run our installer, which downloads the pack into a WorkAgent folder in your Documents. There is no file to download by hand and no personal download link.

Aside will ask permission to run the installer and to use that folder. Allow it. If you prefer a terminal, `bootstrap-terminal.md` has a one line command for Mac, Linux and Windows.

## Step 3. The interview (30 to 40 minutes)

Your agent now runs the setup interview. It will:

1. Explain what it will store and where (only on your computer), and ask your permission.
2. Ask questions in short rounds, about 4 at a time. For each question it tells you why it is asking and what it will change.
3. Give you a few tiny lessons as you go ("here is what a skill is", "here is why we start in read only").
4. Offer to take a read only look at your inbox, calendar and a spreadsheet to understand your real situation. You can say no to any of it.
5. Build your setup: your rules file, your tailored skills, up to three routines, and your 30 day plan.
6. Run one safe first win: a morning briefing preview.

Tips:
- Answer in your own words. Messy answers are fine. "Not sure" is a valid answer.
- You can say "skip", "later" or "explain" to any question.
- Never type passwords, card numbers or security codes.
- Say "pause" any time. Say "continue setup" later to resume.

## Step 4. Use it for two weeks at the safe level

You start at trust level 0 or 1 (read and draft only). Follow the 30 day plan the agent gives you. After 14 days, say "Run my two week review" and it will check your results and suggest what to unlock.

## If something goes wrong

Say what happened to the agent. If it is stuck, see guide/11-troubleshooting.md, or contact your instructor.
