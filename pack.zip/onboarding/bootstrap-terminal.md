# Optional: install with one terminal command

For students comfortable with a terminal. The paste prompt in bootstrap-prompt.txt does the same job and needs no terminal.

The installer is a short, readable text file. You can open https://kazba22.github.io/wa-get-3r2mqx5p/install.sh (or install.ps1) in your browser first and read it. It downloads the pack, unpacks it into a WorkAgent folder in your Documents, never uses admin rights, and never touches your accounts.

## Mac or Linux (Terminal)

```
curl -fsSL https://kazba22.github.io/wa-get-3r2mqx5p/install.sh | bash
```

## Windows (PowerShell)

```
irm https://kazba22.github.io/wa-get-3r2mqx5p/install-windows.txt | iex
```

## If you were given an access code

Mac or Linux:

```
curl -fsSL https://kazba22.github.io/wa-get-3r2mqx5p/install.sh | WORKAGENT_CODE=YOURCODE bash
```

Windows:

```
$env:WORKAGENT_CODE = "YOURCODE"; irm https://kazba22.github.io/wa-get-3r2mqx5p/install-windows.txt | iex
```

## After it finishes

The installer prints one sentence. Open Aside, start a new task, and paste that sentence. Aside then runs the setup interview.

If you use the Aside command line tool, you can also start it from the terminal:

```
aside "Read the file in WorkAgent/pack/onboarding/AGENT-START.md in my Documents folder and follow it exactly."
```

## Updating later

Run the same install command again. It replaces the pack folder with the newest version and does not touch your profile folder (your answers, rules and plan). Then tell Aside: "Compare the VERSION file in my WorkAgent pack with my installed skills and update my skills without changing my rules or profile."
