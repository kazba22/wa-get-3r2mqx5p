# Outputs: what to build after the interview

Save inside the WorkAgent folder, in a subfolder named profile. Create it if missing. Use plain markdown. Show each file to the user before relying on it.

## 1. profile/profile.md

Sections, each with the user's own words where possible:

- Who: name, role, company type and size, languages, schedule, time zone
- AI level and track (A, B or C), attitude to AI (excited, curious, nervous)
- Real work: how the day goes, top repeated tasks, tasks they dread
- Pain ranking of the four areas
- Tools and accounts: which is work, which personal (no passwords)
- Style: description approved by the user
- People: VIPs and ignorable senders (names and roles only)
- Boundaries: confidential data, worst case, approval-always list
- Trust level and the date to review it
- Phone and availability: plan, computer, bot or task inbox
- Goals: what a great month looks like, hours target, what would make them quit
- Preferences on how to be helped
- Open questions: what is still unknown

No passwords, no card numbers, no ID numbers, no bank details, no contents of emails.

## 2. profile/my-rules.md

Start from templates/about-me-and-rules.md. Fill every field from the answers. Keep the hard rules unchanged and add the user's worst case and approval-always items as extra hard rules in their own words. Show it, make corrections, then offer to save it as the user's standing instructions (Aside memory or agent rules, whichever the user prefers) after a clear yes.

## 3. Tailored skills

Install only the skills that match priorities. Map:

| Pain or need | Skill |
|---|---|
| Email | office-inbox-manager |
| CRM or notes | office-crm-notes |
| Spreadsheets | office-spreadsheet-helper |
| Calendar or meetings | office-calendar-meetings |
| Any scheduled briefing | office-daily-briefing |
| Always | office-agent-coach |

Install by copying the whole skill folder (SKILL.md and any references) from the pack into the user skills location of the account. Confirm the path with the user. Then adapt the copies with their details: stage names, labels, meeting rules, VIP pointers (refer to my-rules.md, do not duplicate content), language. Tell the user in one sentence what you changed in each. Keep the original pack copies untouched. Validate that each SKILL.md starts with front matter containing name and description in double quotes.

If there is a need not covered (for example customer support replies, weekly reports for a specific tool), propose a new custom skill: name, one line purpose, steps. Create it only after approval. For Track C users, offer to write it together.

## 4. Routines (maximum three on the Free plan)

Propose from templates/prompt-library.md, personalised:

1. Morning briefing (always the first)
2. Drafts and follow ups (only at level 1 or above)
3. End of day wrap up, or a weekly report, depending on their goals

Show the exact prompt, the schedule in their time zone, the permission mode (Read only or Guard) and where the result is saved. Create after a clear yes. If they want a phone task inbox sheet, create that as one of the three.

## 5. profile/opportunity-map.md

A ranked list of 8 to 12 opportunities specific to their role. For each: what it is, which skill or routine does it, effort (low, medium, high), risk (low, medium, high), expected benefit in words (do not invent time numbers), and suggested week to start. Include 2 or 3 things the user did not mention but their answers suggest (for example a weekly CRM review, a template library, a stale thread chaser). End with "Not recommended yet" items and why.

## 6. profile/30-day-plan.md

Use guide/12-first-30-days.md as the skeleton. Replace generic steps with their tools, their routines, their review dates (day 3, 14, 30), and their level decision rule.

## 7. profile/progress.md

During the wizard, record: rounds completed, answers pending, permissions granted, files created, skills installed, routines created. Update after each round.

## Memory

Offer to save a compact profile summary (maximum 12 lines) to Aside memory: role, language, style headline, tools, trust level, hard rules reference, goals. Save only after a clear yes. Tell the user how to remove it later in Aside's memory settings.

## Final message to the user

Under 15 lines: what was built (files and skills, routines), the trust level and why, tomorrow's first actions, review dates, and the commands "continue setup", "redo round N", "run my weekly review", "run my two week review".
