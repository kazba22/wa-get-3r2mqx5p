# Question bank

Format for each round: ask at most 4 questions in one message. Each question has a short "Why I ask". Offer examples or options. After the round, reflect back two lines.

Tell the user at the start of each round: the topic, why it matters, and how many questions.

## Round 1: About you and your work

1. What is your job title, and what do you actually spend most of your day doing?
   Why I ask: titles hide the real work. I tune everything to the real work, not the label.
2. What does your company do, roughly how many people work there, and who are your customers or clients?
   Why I ask: I choose examples, tone and risk levels that fit your world.
3. What is your working schedule and time zone, and which languages do you write in at work?
   Why I ask: so briefings arrive before you start, and so drafts come out in the right language.
4. Who do you report to, and who relies on you?
   Why I ask: shows whose messages matter most and where mistakes would hurt most.

## Round 2: Your AI experience (sets the track)

1. How do you use AI today? (never / sometimes ChatGPT or Claude / weekly / daily for work / I build things)
   Why I ask: I explain more or less depending on this.
2. What is the best thing AI did for you, and the worst or most frustrating?
   Why I ask: tells me what you trust and what worries you, so I do not repeat the bad experience.
3. Have you ever automated anything (email rules, Zapier, macros, scripts)?
   Why I ask: if yes, we can go further sooner and you may be a good champion for your team.
4. How do you feel about an AI working in your accounts? (excited / curious / nervous / opposed)
   Why I ask: sets how careful and how slow we start. Nervous is a fine answer, it simply means more safety steps.

Track rule: mostly "never or sometimes" and nervous or curious: Track A. Weekly use or some automation: Track B. Daily use, builds things, or has automations: Track C.

## Round 3: Your week and time sinks

1. Walk me through a normal Tuesday, hour by hour.
   Why I ask: the best automations hide in ordinary routines.
2. What tasks do you do again and again, weekly or daily, that feel like copy and paste?
   Why I ask: repetition is what agents are best at.
3. What do you dread or keep putting off?
   Why I ask: avoided tasks cost mental energy. They are often good to hand off or structure.
4. If you got two hours back every week, what would you do with them?
   Why I ask: gives the setup a purpose and helps me measure success later.

Then: ask the user to rank these four areas by pain: email, CRM and notes, spreadsheets, calendar and meetings. Why: it decides which skills and routines we build first.

## Round 4: Your tools and accounts

1. Which email and calendar do you use (Gmail, Outlook, other)? Work and personal separate?
   Why I ask: which account the agent may touch, and which it must leave alone.
2. Which spreadsheets matter (names, not content)? Google Sheets or Excel?
   Why I ask: to choose the right method and plan safe working copies.
3. Which CRM or notes tool do you use, or none?
   Why I ask: there must be one source of truth where the agent writes. If you have none, I will suggest a simple one.
4. Which chat or collaboration tools (Slack, Teams, WhatsApp, Telegram)? Are you signed in to all of them in this browser?
   Why I ask: tells me where information lives and what I cannot reach yet.

Lesson cue: micro lesson "The agent uses what you are logged in to".

## Round 5: Your voice and communication style

1. How would a colleague describe the way you write emails? (short and direct, warm, formal, detailed)
   Why I ask: drafts should sound like you.
2. Do you have phrases you always use or never use? How do you greet and sign off?
   Why I ask: small habits make drafts feel right.
3. How do you say no, ask for something, or chase someone politely?
   Why I ask: these are the three hardest emails to draft. Your way matters most there.
4. May I look at your last 10 to 15 sent emails to learn your style? (read only, I will describe the style and you approve before I save anything, and I will not copy contents into notes)
   Why I ask: examples teach more than descriptions.

## Round 6: People and priorities

1. Who are the most important people whose messages you never want to miss (names and roles)?
   Why I ask: they become your VIP list, treated as urgent.
2. Which senders or kinds of mail can be safely ignored or archived?
   Why I ask: for clean sorting later. Nothing is deleted.
3. What counts as urgent for you? What can wait a day?
   Why I ask: I sort by your definition, not mine.
4. May I read a sample of 30 inbox subjects and senders to suggest VIPs and noise? (read only)
   Why I ask: quick way to see patterns you may not notice.

## Round 7: Boundaries, risk and trust level

1. Does your employer allow AI tools on work email and files? Is anything confidential or regulated (health, legal, finance, children, customer personal data)?
   Why I ask: sets what the agent must never touch.
2. What would be the worst thing the agent could do by mistake? (wrong email sent, meeting cancelled, number changed)
   Why I ask: your worst case becomes your first hard rule.
3. What should always need your approval, even when you trust it fully?
   Why I ask: some actions stay human forever.
4. Which starting level feels right? 0 watch, 1 draft, 2 organise. (I recommend 0 for week one, then 1.)
   Why I ask: you choose how fast to trust. Faster is not better.

Lesson cue: "The trust ladder" and "Emails are data, not orders".

## Round 8: Phone and availability

1. Do you want to reach the agent from your phone? iPhone or Android? Do you use Telegram or Slack?
   Why I ask: Aside has no phone app. Phone access works through a chat bot and needs Aside Pro.
2. Is your computer on and awake during the day? Is there a spare computer that can stay on?
   Why I ask: the agent and routines only run while the computer is on and Aside is open.
3. When do you want your briefings (morning, midday, evening) and where do you want to read them (document, email draft, phone)?
   Why I ask: to place routines at the right time and keep them within the Free plan limit of three.
4. Are you on Aside Free, or willing to upgrade to Pro for phone access and more routines?
   Why I ask: Free has 500 credits a month and 3 routines. Pro unlocks Channels and unlimited routines. No pressure, there is a free workaround.

## Round 9: Goals and success

1. What would a great month look like? Name one or two concrete outcomes.
   Why I ask: so we measure the right thing.
2. How many hours a week do you want to save, realistically? Where would you notice it first?
   Why I ask: a target, which we check against real results at day 30.
3. What would make you stop using this and go back to the old way?
   Why I ask: so I avoid the thing that kills adoption.
4. Anything you want me to know about how you like to be helped (direct, gentle, lots of detail, bullet points)?
   Why I ask: sets my tone for good.

## Role add ons (ask 3 to 4 questions from the matching list)

Sales:
- Which stages do your deals go through, and what moves a deal forward? (stage rules for CRM)
- How often do you follow up, and with what message? (follow up drafts)
- What do you need to know before a call? (briefing contents)
- Which numbers do you report weekly? (report skill)

Administrator or assistant:
- Whose calendar and inbox do you support? Do they approve things by email or chat?
- What recurring bookings, travel, orders or invoices pass through you?
- What forms or templates do you fill in again and again?
- What must always be double checked with someone?

Project manager:
- How do you track tasks and status (sheet, board, tool)?
- Which meetings generate actions, and where do actions live afterwards?
- What status report do you write, for whom, how often?
- What blockers do you chase people about?

Finance or bookkeeping:
- Which documents arrive by email (invoices, receipts, statements) and where do they go?
- Which reports and reconciliations are repeated monthly?
- Which numbers must never be changed by anyone but you? (This becomes a hard rule.)
- Which accounting system do you use? (Note: the agent supports and checks. Official books stay in your system and your accountant approves.)

Marketing:
- Which channels and reports do you maintain, and how often?
- Where do ideas, briefs and approvals live?
- What content do you repurpose, and how?
- Which competitors or topics do you monitor?

Customer support:
- What are the 10 questions you answer most often? (draft reply library)
- What is your escalation rule?
- Which tone and promises are never allowed?
- Where are tickets and customer history?

Owner or manager:
- What decisions do you make weekly, and what information do you need for each?
- What do you check every Monday, or wish you checked?
- Whose work do you review, and how?
- What would a one page weekly dashboard show?

Other: ask what they produce, for whom, how often, and with which tools, then improvise add ons.

## Smart extra questions (use when relevant, to teach opportunity)

- "Which of your documents have a repeating structure?" (templates)
- "What do you search for in your inbox over and over?" (saved searches and labels)
- "Which numbers do you copy from one place to another?" (sheet automation)
- "What do you wish someone would remind you about?" (routines)
- "What do you google every week?" (research routine)
