# Phone cheat sheet (Telegram bot)

Works when: your computer is on, awake, Aside is open, and you are on the Pro plan.

## Commands

| Send | Does |
|---|---|
| /new | New conversation |
| /stop | Stop the running task |
| /sessions | Switch between conversations |
| /model | Pick model |
| /effort | Think less (cheaper, faster) or more |
| /usage | Credit usage |

## Ask like this

Inbox
- What needs my reply today? Top 5 only.
- Summarise the thread with [name]. What do I owe them?
- Draft a reply to [name]: [what to say]. Draft only.

Calendar
- What is my next meeting? 5 line brief.
- Find 45 minutes tomorrow for focus time. Propose, do not create.
- Draft a message: I am 10 minutes late to the [time] meeting.

CRM and notes
- Log: met [name] at [company], [what happened], follow up [day]. Show me the change list.
- Who is [name]? Our history in 5 lines.

Spreadsheets
- Add a row to [sheet]: [values]. Show me the row first.
- What are this month's totals in [sheet]?

## Safety reminders

- The bot only answers you ("Only me"). Do not change that.
- Never send passwords, card numbers or codes in the chat.
- Anything that sends, deletes, pays or invites people: the agent must ask you first. If it does not ask, say stop.
- Silent bot means the computer is asleep or Aside is closed.
- Lost your phone: open BotFather in Telegram on another device, choose your bot, regenerate the token, and paste the new token in Aside Settings > Channels.
