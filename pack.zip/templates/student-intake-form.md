# Student intake form (instructor fills in with the student, 15 minutes)

Purpose: decide the right setup, the right plan and the safe starting level before the workshop.

## 1. Person

- Name and role:
- Company and size:
- Computer: Mac / Windows / shared / company managed
- Phone: iPhone / Android
- Languages used at work:

## 2. Permission

- Does the company allow AI tools on work email? Yes / No / Unknown
- Who approves (manager or IT)?
- Any data that must never be processed (health, legal, bank, children, special categories)?

## 3. Tools

| Area | Tool they use | Signed in on this computer? |
|---|---|---|
| Email | Gmail / Outlook / other | |
| Calendar | Google / Outlook / other | |
| Spreadsheets | Google Sheets / Excel | |
| CRM | | |
| Notes | | |
| Chat | Slack / Teams / Telegram / WhatsApp | |

If Outlook or Microsoft 365: flag. The skills are tuned for Google, the agent will work through the website and it is slower.

## 4. Pain and priorities (rank 1 to 4)

- Email overload
- CRM and notes always out of date
- Spreadsheet reporting and cleanup
- Calendar and meetings

Most painful hour of the week:

## 5. Phone access

- Wants it from the phone? Yes / No
- Plan: Free (task inbox) / Pro (Telegram bot)
- Computer that can stay on? Yes / No / Laptop only
- Telegram installed? Slack admin rights?

## 6. Starting setup

- Starting trust level: 0
- First routine: morning briefing
- First 3 skills: 
- Review day (check in call): 

## 7. Agreement

Student understands: the agent can make mistakes, they approve anything sent in their name, they will follow company policy, we do not store their passwords, and we do not receive their data.
